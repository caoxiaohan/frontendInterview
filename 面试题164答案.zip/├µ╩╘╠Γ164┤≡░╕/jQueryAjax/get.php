<?php

// 结果出错
// 在调用 header() 之前已存在输出
echo "This is some text from an external php file.";
  
?>