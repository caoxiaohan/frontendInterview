<?php  
   header("Access-Control-Allow-Origin:*");  
   echo "来自远程服务器";
 ?>