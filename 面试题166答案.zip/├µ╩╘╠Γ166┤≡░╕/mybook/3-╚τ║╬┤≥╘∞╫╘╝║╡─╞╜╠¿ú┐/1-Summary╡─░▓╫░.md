## Summary的安装

罗嗦那么多，才入正题（如果是高考，这辈子算交代了）。

安装很简单，大致流程如下：

#### 安装node.js（含npm)

建议使用`nvm`安装，下面这篇文章讲的很到位，直接参考下吧

地址： https://cnodejs.org/topic/5338c5db7cbade005b023c98

#### 安装Summary

命令：

```
$ npm install -g gitbook-summary
```

