var data = [];
for (var i = 1; i <= 1000; i++) {
    var ran = Math.round(Math.random() * 9 + 1);
    data.push("img/" + ran + ".jpg");
}


