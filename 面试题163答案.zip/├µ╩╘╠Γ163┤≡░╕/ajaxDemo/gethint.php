<?php
echo $_GET["q"];
?>